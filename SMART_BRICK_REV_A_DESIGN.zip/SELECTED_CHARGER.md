# Selected charger module

User-selected product: https://www.amazon.in/dp/B0GYDLWV94

Inspected the listing and enlarged board photos. Listed size is 28 × 17 × 4 mm. USB-C TP4056 charger with advertised DW01A/8205A battery protection and nominal 1 A charging. Board pads are B+, B−, OUT+, OUT−, plus charging input + and − near USB. No mechanical drawing of pad-centre coordinates was provided. Reserve a 28 × 17 mm body and USB access; direct solder mounting footprint needs confirmed pad coordinates or a mounting method tolerant of variant pads.

This identifies the charger, not a completed PCB. Protected output follows the cell voltage; it is not a 3.7 V regulated output. Battery-specific charge current, load power path and regulated ESP32 supply remain part of the board design.

## Battery and motor update

- Confirmed battery: one 3.7 V nominal LiPo cell, 500 mAh. Cell dimensions and manufacturer charge-current limit are still unknown.
- Proposed initial charging current: approximately 100 mA (0.2 C), subject to the cell specification. A TP4056 variant using the 1200/current relationship uses approximately 12 kΩ at PROG; verify the actual charger IC datasheet and measure current after replacing its onboard resistor. The selected module advertises 1 A by default, equivalent to 2 C for this battery; do not assume that setting is permitted.
- Selected ERM is Electronic Spices B0D2P4Y6S8 / supplier SKU IF8501A1, published rating 3 V DC, 150 mA, 10,000 RPM. Use a regulated 3.0 V motor supply; startup/stall current and physical envelope still need verification. Do not connect directly to the LiPo: a fully charged cell is approximately 4.2 V. See SELECTED_MOTOR.md.
- Carrier must preserve the protection path: battery connects to B+/B−, system connects to OUT+/OUT−; do not bridge B− to OUT−.

Charging reference: https://www.umw-ic.com/static/pdf/1c10411cf0937f9f813d2f3f7dea7cda.pdf
