# Assembly and first power-up

## Before fabrication

1. Print the fit template at Actual size and verify the 50 mm bar with a ruler.
2. Match every module header to its numbered carrier pads using CONNECTIVITY.csv. Pay particular attention to the ESP32 clone pin order, MPU10-pin order, RC522 power end and HW-201 VCC/GND/OUT order. Module bodies drawn in the layout are provisional mechanical envelopes.
3. Check the enclosure's optical apertures, reader height, USB-C access, battery volume and motor moving clearance. Charger/booster link wires must be insulated and mechanically secured. Revise CAD if needed and rerun DRC before exporting new Gerbers.

## Populate and wire

1. Fit SMD components. Q1 and D2 are on the bottom. C3/C4 are bottom-mounted polarized capacitors; observe their + pads. Fit U5 specifically as TLV75530PDBVR (3.0 V, DBV/SOT-23-5): 1 IN, 2 GND, 3 EN, 4 NC, 5 OUT.
2. D1 cathode/banded end (pad1) goes to ESP_VIN; anode pad2 goes to BOOST_5V. D2 cathode/banded end (pad1) goes to MOTOR_VM; anode pad2 goes to MOTOR_LOW. Both are SS14 in SMA.
3. Fit two 1x15 ESP32 sockets, the selected module headers and JP1/JP2. Leave both jumpers open. Leave R6-R11 unpopulated initially. Use insulating supports so breakout boards cannot contact exposed pads/tracks.
4. Mount charger and booster on their reserved PCB areas. Make these short connections by the modules' printed SIGNAL LABELS, not by their apparent photo orientation:

| From | To |
|---|---|
| Charger OUT+ | J5 pad1 |
| Charger OUT- | J5 pad2 (system GND) |
| Charger B+ | J6 pad1 (CELL_POS) |
| Charger B- | J6 pad2 (CELL_NEG) |
| LiPo positive lead | J7 pad1 |
| LiPo negative lead | J7 pad2 |
| Booster VIN | J8 pad1 (BAT_RUN) |
| Booster GND | J8 pad2 |
| Booster VOUT, 5 V | J8 pad3 |
| ERM positive lead | M1 pad1 |
| ERM negative lead | M1 pad2 |

5. Secure the motor in an insulating cradle/adhesive restraint with its weight free to rotate. Motor leads and nearby housing must stay outside the moving envelope.
6. For the common-cathode RGB LED, verify lead colours with a diode test before soldering: carrier D3 pads1=R, 2=common cathode/GND, 3=G, 4=B. Each anode has its own 220 ohm resistor.
7. Change the charger's onboard charge-setting resistor only after identifying its fitted IC and PROG circuit. Approximately 12k is a starting value for the cited TP4056 variant's approximately 100 mA setting. Do not leave the default advertised 1 A setting without a matching battery charge specification. Measure the actual charge current.

## Verify before attaching the battery

1. Inspect all solder joints and diode/regulator orientation. Check for a direct short from each supply rail to GND. CELL_NEG must not be directly soldered to system GND; the charger's protection circuitry lies between them.
2. Initially power the system side from a current-limited bench supply at roughly 3.7 V on J5 OUT+/OUT- with the battery/charging USB disconnected. Leave JP2 open and initially omit the ESP32/sensor modules.
3. Fit JP1 and measure J8 VOUT near 5 V, ESP_VIN slightly below 5 V because of D1, and JP2 pad1 near 3.0 V. Correct any polarity/voltage problem before fitting modules. Bench supply current limiting may need raising for startup; determine the required value from measurements rather than assuming that 150 mA motor running current is the system maximum.
4. Switch off, fit ESP32 and modules, then confirm 3V3 and sensor supply levels. Verify shared I2C scanning and each face input with the existing diagnostic firmware.
5. Program with JP1/JP2 open. If the on-carrier ESP32 USB plug cannot clear the west IR module/enclosure, remove the socketed ESP32 and flash it separately. D1 prevents programming USB voltage from feeding backward into the booster output; its voltage does still power the sensor 3V3 rail through the ESP32 board.
6. Fit JP2 only after measuring the motor supply. Check GPIO26 low leaves the motor off, then command a short pulse. Measure startup current and observe the ESP supply while Wi-Fi transmits. Check U5/booster temperatures and ensure the battery can support measured peaks before extended operation.
7. Power down before replacing bench power with the LiPo. Check polarity at J7 again. For charging, leave JP1 OFF/open and connect 5 V to the charger's USB-C port. Verify charge-current setting and termination; do not operate the tray from this TP4056 while charging.

## Functional prototype checks

- Observe one hotspot gateway and the remaining ESP-NOW bricks; compare dashboard packet freshness before/after RFID scans and vibration pulses.
- Confirm N/E/S/W inputs correspond to the physical face labels and detect nearby brick surfaces at the intended docking distance.
- Verify card/tag scans above every reader with the actual instrument material and tag mounting, not only a bare card.
- Read IMU and external compass independently. The external GY-271 requires its matching firmware driver; an HMC/QMC substitution is not automatically compatible.
- Calibrate/test heading with the motor stopped and running and with instruments present. Magnets, steel instruments, batteries and high-current routing can disturb compass heading.
- Compare the displayed possible configuration with the physical tray. IR occupied-face readings do not uniquely associate neighbouring brick identities.
