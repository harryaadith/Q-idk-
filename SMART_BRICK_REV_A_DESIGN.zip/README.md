# Smart surgery tray brick PCB - Rev A prototype

This package contains a routed, two-layer carrier PCB, an editable KiCad schematic and board, fabrication plots, a BOM and assembly guidance. It preserves the existing firmware GPIO assignments and omits the buzzer. All modules mount physically on the carrier. Charger and booster connections use short solder links because this avoids guessing undocumented or reversed module pad coordinates.

## Open and review

Use KiCad 10 or newer and open `cad/smart_brick.kicad_pro`. The custom footprint library is included and uses a project-relative path. The schematic uses net-labelled component/header blocks: equal net labels are connected electrically. CHG1 and BOOST1 describe the mounted modules; J5/J6/J8 describe their actual carrier solder links. Their internal commercial circuitry is not reproduced.

`SMART_BRICK_SCHEMATIC.pdf` is a readable export; `CONNECTIVITY.csv` lists every carrier pad and signal. `BOM.csv` identifies the assembly side and unpopulated options. `PCB_LAYOUT.png` shows routed tracks with ground fills omitted for clarity. Actual ground fills are present in the CAD and Gerbers.

## Board and fit

- Carrier envelope: 110 x 110 mm, 1.6 mm FR4, two copper layers, nominal 1 oz copper. The 32 x 15 mm open notch beneath the ESP32 antenna is part of the outline.
- ESP32: two 15-pin socket rows, 2.54 mm pitch, 25.4 mm row-centre separation. GPIO order assumes the common 30-pin DOIT/WROOM layout; check the actual clone.
- Upward-facing RC522: nominal 60 x 40 mm. Keep antenna area free of carrier copper on both sides.
- MPU9250: 10-pin header, 2.54 mm pitch; proposed body 15 x 25 mm. Header/body offset remains provisional.
- GY-271: 5-pin header, nominal 14.8 x 13.5 mm. Confirm whether the delivered module is HMC5883L or QMC5883L and compare its printed pin order.
- HW-201: four outward-facing modules, nominal 32 x 14 mm. Sensor optical ends must remain exposed at the four tray faces. The south body extends 2 mm beyond the carrier; emitter packages may extend further.
- Selected TP4056 module: nominal 28 x 17 mm, USB-C facing the south edge. Secure on insulating adhesive spacers; connect labelled pads to J5 and J6 with short insulated links.
- New 5 V booster: Pololu U3V16F5, nominal 13.1 x 8.1 mm, secured on insulating spacers. Connect its labelled pins to J8; no guessed physical pin order is imposed.
- ERM: user-measured 13 x 5 mm body. The 21 x 13 mm placement allowance includes assumed up-to-3 mm weight protrusion plus 1 mm clearance on every side. Use an insulating restraint, keep the moving weight clear, and solder leads to M1. Q1 and D2 are on the underside to keep the top motor space clear.
- Chassis holes: 3.2 mm NPTH at (3,18), (92,35), (46,106), (107,79), measured from the upper-left envelope corner in top view. Use nonmagnetic hardware and sufficient module height clearance.

Print `FIT_CHECK_TEMPLATE.pdf` at 100%, measure its 50 mm scale bar, and compare **every actual module and pin label** before ordering. Several breakout header offsets are inferred rather than manufacturer-dimensioned. A clean electrical DRC does not certify their mechanical fit. Revise CAD if a board does not match. Battery dimensions, enclosure height and the measured rotating-weight envelope are still unverified. The battery must not sit beneath the reader antenna or beside the compass.

## Power and assembly

Follow `ASSEMBLY_AND_BRINGUP.md`. One 500 mAh, 3.7 V nominal LiPo connects to the charger's B+/B- through J6/J7. Protected OUT+/OUT- connect through J5. **CELL_NEG and GND are distinct: never bridge B- and OUT-.** JP1 enables operation. Leave JP1 open during charging because TP4056 has no load-sharing power path.

The protected battery voltage feeds the 5 V booster and the separate TLV75530PDBVR motor regulator. D1 isolates the booster from ESP32 programming-USB power. All sensors use ESP32 3V3, not raw battery voltage. JP2 isolates the motor for bring-up. Q1 provides default-off low-side switching from GPIO26; D2 supplies flyback protection. Never substitute a 3.3 V regulator for the specified 3.0 V motor regulator without reassessing the motor rating.

The selected motor's supplier publishes 3 V, 150 mA running current and 10,000 RPM; startup/stall current is not specified. Measure it and check regulator temperature before extended operation. Verify the battery can supply the measured full-system peaks. Charging current is provisionally about 100 mA (0.2 C); the selected TP4056 board advertises 1 A by default. Its onboard PROG resistor must be replaced for the actual IC's equation, and charge current must be measured and checked against the battery specification.

R6-R9 are optional 10k IR pull-ups; R10/R11 are optional 4.7k I2C pull-ups. Leave these unpopulated initially because breakouts generally contain pull-ups; fit only after checking the total bus/output resistance. Check IR VCC/GND/OUT order and use 3.3 V power so the ESP inputs cannot receive a 5 V module pull-up.

## Verification and limitations

`DRC_REPORT.json` records the final KiCad clearance/connection check. `CONNECTIVITY_CHECK.json` compares the schematic's exported netlist and PCB against all 111 assigned carrier pads across 36 components and 30 nets. Local schematic net names are compared after normalizing the root-sheet prefix; declared NC pins are excluded. These are design checks, not hardware tests.

The layout has not been built or electrically measured. RF performance, sensor interference, thermals, battery limits and breakout fit require prototype validation. The external GY-271 needs a compatible firmware driver; this package adds hardware connections only and does not alter firmware. Compass headings cannot identify physical neighbours by themselves. The existing IR-only dashboard still infers a possible arrangement.

No files or branches in the main project repository were modified for this PCB package. Earlier `PRELIMINARY_PLACEMENT` and `PCB_CONNECTION_PLAN` files are superseded by this Rev A package.

## Fabrication files

`SMART_BRICK_REV_A_GERBERS.zip` contains copper, solder mask, silkscreen, the notched outline, separate PTH and NPTH drill files, an IPC-D-356 connectivity netlist and this prototype's fabrication notes. It does not contain the schematic or module body outlines as extra milling outlines. `SMART_BRICK_REV_A_DESIGN.zip` contains the full review package.

Verify the 1:1 fit first. Then select 2 layers, 1.6 mm FR4, 1 oz copper and the manufacturer's standard solder mask/finish. Import both drill files and the complete outline, including the antenna notch. No manufacture order has been placed.

## Component references

- Motor supplier: https://electronicspices.com/product/3v-10000-rpm-dc-vibrator-motor
- Selected charger: https://www.amazon.in/dp/B0GYDLWV94
- TP4056 example IC datasheet (confirm actual fitted vendor): https://www.umw-ic.com/static/pdf/1c10411cf0937f9f813d2f3f7dea7cda.pdf
- Motor regulator: https://www.ti.com/lit/ds/symlink/tlv755p.pdf
- Booster: https://www.pololu.com/product/4941
- Booster dimensions: https://www.pololu.com/file/0J1921/step-up-voltage-regulator-u3v16fx-dimensions.pdf
- Compass dimensions: https://robu.in/wp-content/uploads/2019/05/GY_271_ELECTRONIC_COMPASS1.pdf
- RC522 module: https://robu.in/product/rc522-rfid-card-reader-module-13-56mhz/
