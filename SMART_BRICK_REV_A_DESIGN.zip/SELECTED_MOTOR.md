# Selected ERM motor

User-selected Amazon ASIN: B0D2P4Y6S8
https://www.amazon.in/dp/B0D2P4Y6S8

Brand supplier listing: https://electronicspices.com/product/3v-10000-rpm-dc-vibrator-motor
Supplier SKU: IF8501A1

Published electrical ratings: 3 V DC, 150 mA rated current, 10,000 RPM. These agree with the Amazon title and specification bullets inspected in the browser. Rated electrical input is approximately 0.45 W; it does not establish mechanical output power. Startup and stall current are not specified.

Design requirement: supply from a regulated 3.0 V motor rail with GPIO26 controlling a low-side MOSFET, gate resistor, gate pulldown, flyback diode and local decoupling. Do not drive directly from GPIO or the unregulated 1S LiPo. Select regulator and MOSFET for measured startup/stall current, not only the 150 mA running rating.

User reports motor length 13 mm and width 5 mm. Treat these as the motor body dimensions provisionally: the user has not stated whether the length includes the eccentric weight. User-authorized assumption: the rotating weight extends no more than 3 mm beyond the body. Reserve 1 mm additional clearance around the moving envelope. A conservative rectangular placement allowance is 21 × 13 mm (13 × 5 mm body plus 4 mm on all sides); this is a layout allowance, not measured motor geometry. Mount the motor mechanically on the PCB with an adhesive cradle or suitable restraint and connect its leads to two solder pads; these body dimensions do not define terminal pitch. The earlier coin-shaped placement preview is obsolete and must be revised before release.

Keep motor and high-current routing separated from the external compass; verify magnetic heading disturbance on the assembled brick.
